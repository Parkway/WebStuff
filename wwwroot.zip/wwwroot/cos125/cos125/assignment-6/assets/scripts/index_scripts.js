//scripts for assignment 5


function today(){

	let today = new Date();
	let date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();

	document.getElementById("today").innerText = date;

}

function rand_num(){
	return Math.floor(Math.random()*100);
}

function greet(){
	
	alert('Hello!, I know Javascript now! Prepare yourself for some mad LIVE content');
	
	// call the today() function
	today()

	let mynum= rand_num();

	alert('I bet your favorite number is: '+String(mynum));
} 

// onload event handler
document.getElementById("slayer").addEventListener("load", grow);

// click handler
document.getElementById("slayer").addEventListener("click", shrink);

// scroll handler
document.addEventListener("scroll", change_bg);

function grow(){
	document.getElementById("slayer").style.width = "400px";
	document.getElementById("slayer").style.height = "500px";
}


function shrink(){
	document.getElementById("slayer").style.width = "200px";
	document.getElementById("slayer").style.height = "100px";

}

function change_bg(){
	var random_color = Math.floor(Math.random()*16777215).toString(16);
	document.body.style.backgroundColor = '#'+random_color;
}

//change cursor
document.getElementById("slayer").style.cursor = "crosshair";




