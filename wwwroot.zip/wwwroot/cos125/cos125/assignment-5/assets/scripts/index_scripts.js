//scripts for assignment 5


function today(){

	let today = new Date();
	let date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();

	document.getElementById("today").innerText = date;

}

function rand_num(){
	return Math.floor(Math.random()*100);
}

function greet(){
	
	alert('Hello!, I know Javascript now! Prepare yourself for some mad LIVE content');
	
	// call the today() function
	today()

	let mynum= rand_num();

	alert('I bet your favorite number is: '+String(mynum));
} 


